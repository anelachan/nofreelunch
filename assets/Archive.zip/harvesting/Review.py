# Name: Review.py
# Author: Anela Chan
# Date: March 2015
# Description: Extract review data for a product (using product URL)
# Visit review pages, scrape based on structure/patterns, insert into database.

import requests
import re
from bs4 import BeautifulSoup
from datetime import datetime
from pymongo import MongoClient
from pymongo import errors
import bson

REVIEW_SECTION = '.review'
REVIEW_TITLE = {'class': 'review-title'}
REVIEW_DATE = {'class': 'review-date'}
REVIEW_AUTHOR = {'class': 'author'}
REVIEW_TEXT = {'class': 'review-text'}
REVIEW_STARS = {'class': 'review-rating'}
REVIEW_HELPFUL = {'class': 'review-votes'}
NO_REVIEWS = {'class':'no-reviews-section'}

class Review(object):

	# pass Product object and db object
	def __init__(self,product,db):

		self.db = db
		self.product = product
		self.reviews_url = self.product['url'].replace('dp','product-reviews')

	# crawl review pages based on product's url objects
	def crawl_review_pages(self):
		num = 1
		while (num < 51):

			url = self.reviews_url + '?pageNumber=' + str(num)
			page = requests.get(url)
			soup = BeautifulSoup(page.text)
			# only flagged if at non-existent page
			no_reviews = soup.find(attrs=NO_REVIEWS)

			if not no_reviews:
				try:
					self.scrape_page(soup)
					print 'Recorded %s' % url
				except (IndexError, AttributeError, ValueError):
					print 'Error on page %s' % num
					db.product.update(
						{'_id': self.product['_id']},
						{ '$push' : { 'failures' : url } }
					)
				num += 1

			else: 
				break
		self.conn.close()

	# purpose: scrape all product reviews form web page
	# input: HTML text
	# output: void, inserts into database
	def scrape_page(self,soup):
		reviews = soup.select(REVIEW_SECTION)[1:-1]
		for el in reviews: # el is a soup object
			review = {}
			review['title'] = el.find(attrs=REVIEW_TITLE).string
			review['date'] = datetime.strptime(
				str(el.find(attrs=REVIEW_DATE).string)[3:],'%B %d, %Y')
			review['author'] = self.get_author(el)
			review['review'] = el.find(attrs=REVIEW_TEXT).contents[0]
			review['stars'] = float(el.find(attrs=REVIEW_STARS).string)
			helpful = self.get_helpful(el)
			if helpful:
				review['helpful_votes'] = helpful[0]
				review['votes'] = helpful[1]
			review['product_id'] = self.product['_id']
			review['category'] = self.product['category']

			# attempt to add to database
			try:
				self.db.review.insert(review)
				return True
			except (bson.errors.InvalidDocument, errors.DuplicateKeyError):
				print 'Error inserting following review:'
				print review
				return False

	# purpose: extract author name if it exists
	# input: soup/dom obj containing one review
	# output: author name or None
	def get_author(self, soup_obj):
		try:
			return soup_obj.find(attrs=REVIEW_AUTHOR).string
		except AttributeError:
			# a few reviews are anonymous, like if reviewer is underage
			return None

	# purpose: extract helpful votes if they exist
	# input: soup/dom obj containing one review
	# output: list object of [# helpful, # of votes total]
	def get_helpful(self, soup_obj):
		try:
			helpful = str(soup_obj)
			match_obj =  re.search('((\d+)?,?(\d+)) of ((\d+)?,?(\d+)) people found the following review helpful',helpful)
			return [int(match_obj.group(1).replace(',','')),
							int(match_obj.group(4).replace(',',''))]
		except AttributeError:
			# some reviews do not have helpful votes
			return None

	# retries products for ALL products
	# has nothing to do with a product category
	def retry_failures(self):
		for product in self.db.product.find({'failures': {'$not': {'$size': 0}}}):
			r = Review(product,db)
			for failure in product['failures']:
				print 'Attempting %s' % failure
				page = requests.get(failure)
				soup = BeautifulSoup(page.text)
				success = r.scrape_page(soup)
				if success:
					db.product.update({'_id':product['_id']},
						{'$pull': {'failures': failure}})
