# Name: Product.py
# Author: Anela Chan
# Date: March 2015
# Description: Collect all the URLs for a given product category.
# Warning: Products further down in the search results may only be tangentially
# related to the product category.

import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient

LAST_PAGE = {'class':'pagnDisabled'}
BASE_URL = 'http://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords='
PAGE_LINKS = '.s-access-detail-page'

class ProductCategory:

	def __init__(self,keyword_str):
		self.init_url = BASE_URL + keyword_str.replace(' ','%20')
		self.page = requests.get(self.init_url)
		self.soup = BeautifulSoup(self.page.text)
		self.num_pages = int(self.soup.find(attrs=LAST_PAGE).contents[0])
		self.urls = []

	def grab_page_urls(self):
		product_page_links = self.soup.select(PAGE_LINKS)
		for a in product_page_links:
			if a not in self.urls:
				self.urls.append(a['href']+'/')

	def crawl_pages(self):
		self.grab_page_urls()
		for num in range(2,self.num_pages):
			url = self.init_url + '&page=' + str(num)
			# visit and download page
			self.page = requests.get(url)
			self.soup = BeautifulSoup(self.page.text)

			self.grab_page_urls()


if __name__ == '__main__':
	client = MongoClient('localhost', 27017)
	db = client['nofreelunch']

	keyword = 'wireless printer'
	# create product category object with name, urls, product info
	pc = ProductCategory(keyword)
	pc.crawl_pages()
	db.productcategory.insert({
		'name': keyword,
		'urls': pc.urls,
		'failures': []
	})


