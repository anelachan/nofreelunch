# Name: Product.py
# Author: Anela Chan
# Date: March 2015
# Description: Extract product data. Visit product URL and record the data.

import requests
import re
from bs4 import BeautifulSoup
from datetime import datetime
import pymongo

PRODUCT_TITLE = {'id':'productTitle'}
PRODUCT_PRICE = {'id':'priceblock_ourprice'} # check this one might be wrong
PRODUCT_BRAND = {'id':'brand'}

class Product(object):

	def __init__(self,productcategory,db):

		self.productcategory = productcategory
		self.db = db

	def crawl_product_pages(self):
		# just do the top 100
		for url in self.productcategory['urls'][:101]:
			if self.scrape_page(url):
				print 'Recorded ' + url
			else:
				self.db.productcategory.update(
					{'_id': self.productcategory['_id']},
					{ '$push' : { 'failures' : url } }
				)

	def scrape_page(self,url):
		page = requests.get(url)
		soup = BeautifulSoup(page.text)
		product = {}
		product['url'] = url
		try:
			product['name'] = soup.find(attrs=PRODUCT_TITLE).string
			price_str = soup.find(attrs=PRODUCT_PRICE).string
			match_obj = re.search(r'\$(\d+.\d\d)',price_str).group(1)
			# assume price is never less than $1
			product['price'] = float(match_obj)
			product['brand'] = soup.find(attrs=PRODUCT_BRAND).string
			product['category'] = self.productcategory['name']
			product['timestamp'] = datetime.now() # price may change in future
			product['failures'] = []
			try:
				self.db.product.insert(product)
				return True
			except pymongo.errors.DuplicateKeyError:
				return False
		except AttributeError:
			return False

	def retry_failures(self):
		for url in self.db.productcategory.find_one(
		{'category': self.category['name']})['failures']:
			self.scrape_page(url)
