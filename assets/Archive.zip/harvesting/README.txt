ABOUT

These scripts crawl and scrape Amazon to download product and review information. They are included for reference/completeness but it is NOT recommended that you run them for building the software demo as they require costly HTTP requests, and Amazon may block your IP after receiving too many requests! Instead, text data and a script to build the database is provided in /assets/data and /assets/build.py.


EXAMPLE USAGE

from pymongo import MongoClient

# connect to database
client = MongoClient('localhost', 27017)
db = client['nofreelunch']

# specify product category keyword
keyword = 'digital SLR'

# create product category object to crawl product category pages
pc = ProductCategory(keyword)
pc.crawl_pages()
category = db.productcategory.insert({
	'name': keyword,
	'urls': pc.urls,
	'failures': []
})

# create a Product object to crawl the product pages
p = Product(category,db)
p.crawl_product_pages()

# create a review obj for each product
for product in db.product.find({'category':keyword}):
	r = Review(product,db)
	r.crawl_review_pages()

# if you need to, retry failures:
r.retry_failures()